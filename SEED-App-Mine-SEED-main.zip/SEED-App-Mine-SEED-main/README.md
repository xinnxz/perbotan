# Seed Mine Bot

## Pengaturan

Instal menggunakan Python

1. Unduh Python 3.10+
2. Instal Modul (pip install requests colorama)
3. Buka Bot di PC (Telegram Desktop)
4. Klik kanan dan pilih Inspect
5. Masuk Application > Session Storage
6. __telegram__initParams Ambil tgwebappdata "query_idxxxx" tidak ada tanda kutip
7. python seed.py

## Fitur
- Tingkatkan Secara Otomatis
- Menerima Secara Otomatis
- Hapus Tugas Secara Otomatis
- Menangkap Cacing Secara Otomatis
- Banyak akun

## Tangkapan layar

![Tangkapan layar aplikasi](https://i.ibb.co.com/6WqnLjM/asdf.png)

